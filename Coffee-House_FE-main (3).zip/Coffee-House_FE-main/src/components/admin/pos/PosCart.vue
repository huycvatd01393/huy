<template>
  <div class="d-flex flex-column h-100 bg-white">
    <div
      class="flex-shrink-0 p-2 shadow-sm d-flex justify-content-between align-items-center z-2 rounded-bottom"
      :class="
        selectedTable?.tableId === 'TAKEAWAY'
          ? 'bg-warning text-dark'
          : selectedTable
            ? 'bg-dark text-white'
            : 'bg-secondary text-white'
      "
    >
      <h6 class="mb-0 fw-bold">
        <i
          class="bi"
          :class="selectedTable?.tableId === 'TAKEAWAY' ? 'bi-bag-check-fill' : 'bi-geo-alt-fill'"
        ></i>
        {{ selectedTable ? ` ${selectedTable.tableName}` : "Chưa chọn bàn" }}
      </h6>

      <div v-if="selectedTable && selectedTable.tableId !== 'TAKEAWAY'">
        <span v-if="selectedTable.isInUse" class="badge bg-danger">Có Khách</span>
        <span v-else class="badge bg-success">Trống</span>
      </div>
    </div>

    <div v-if="selectedTable" class="px-2 py-2 bg-light border-bottom z-3">
      <div class="d-flex flex-column gap-2">
        <div class="d-flex gap-2">
          <div class="position-relative" style="flex: 5.5">
            <div
              v-if="selectedCustomer"
              class="d-flex justify-content-between align-items-center px-2 py-1 bg-success bg-opacity-10 border border-success rounded h-100"
            >
              <div class="d-flex align-items-center min-w-0">
                <i class="bi bi-person-check-fill text-success me-2"></i>
                <span class="fw-bold text-dark small text-truncate">{{ selectedCustomer.fullName }}</span>
                <span class="badge bg-warning text-dark ms-2 flex-shrink-0"
                  >{{ selectedCustomer.rewardPoints || 0 }} điểm</span
                >
              </div>
              <button class="btn btn-sm btn-link text-danger p-0 ms-2 flex-shrink-0" @click="clearCustomer">
                <i class="bi bi-x-circle-fill"></i>
              </button>
            </div>

            <div v-else class="input-group input-group-sm h-100">
              <span class="input-group-text bg-white border-end-0 pe-1"
                ><i class="bi bi-person text-muted"></i
              ></span>
              <input
                type="text"
                class="form-control border-start-0 ps-1"
                placeholder="Tìm tên/SĐT khách..."
                v-model="searchQuery"
                @input="handleSearch"
                @focus="showDropdown = true"
                @blur="hideDropdownDelay"
              />
            </div>

            <ul
              v-if="showDropdown && searchQuery"
              class="dropdown-menu show w-100 position-absolute shadow-sm"
              style="top: 100%; z-index: 1050; font-size: 0.85rem"
            >
              <li v-if="isSearching" class="dropdown-item text-center text-muted py-1">
                <div class="spinner-border spinner-border-sm text-primary" role="status"></div>
              </li>
              <li v-for="c in suggestedCustomers" :key="c.id" @click="selectCustomer(c)">
                <a
                  class="dropdown-item cursor-pointer py-1 d-flex justify-content-between align-items-center"
                >
                  <span class="text-truncate">{{ c.fullName }} - {{ c.phoneNumber }}</span>
                  <span class="badge bg-warning text-dark flex-shrink-0">{{ c.rewardPoints || 0 }} đ</span>
                </a>
              </li>
              <li v-if="!isSearching && suggestedCustomers.length === 0">
                <a class="dropdown-item text-primary cursor-pointer fw-bold py-1" @click="triggerAddCustomer">
                  <i class="bi bi-plus-circle"></i> Thêm mới khách này
                </a>
              </li>
            </ul>
          </div>

          <div class="input-group input-group-sm" style="flex: 4.5">
            <span class="input-group-text bg-white border-end-0 pe-1"
              ><i class="bi bi-ticket-perforated text-muted"></i
            ></span>
            <input
              type="text"
              class="form-control border-start-0 border-end-0 ps-1"
              placeholder="Mã Voucher..."
              v-model="voucherCode"
              :disabled="!!appliedVoucher"
            />
            <button
              v-if="!appliedVoucher"
              class="btn btn-outline-primary px-2"
              type="button"
              @click="applyVoucher"
              :disabled="!voucherCode.trim() || isApplyingVoucher"
            >
              <i v-if="isApplyingVoucher" class="spinner-border spinner-border-sm"></i>
              <i v-else class="bi bi-check2-circle"></i>
            </button>
            <button
              v-else
              class="btn btn-outline-danger px-2"
              type="button"
              @click="removeVoucher"
            >
              <i class="bi bi-x-circle"></i>
            </button>
          </div>
        </div>

        <div
          v-if="selectedCustomer && selectedCustomer.rewardPoints > 0"
          class="form-check form-switch ms-1 mt-1"
        >
          <input
            class="form-check-input cursor-pointer"
            type="checkbox"
            id="switchPoints"
            v-model="useRewardPoints"
          />
          <label class="form-check-label small fw-semibold text-muted cursor-pointer" for="switchPoints">
            Dùng tối đa <span class="text-warning fw-bold">{{ pointsToUse }} điểm</span> để giảm
            <span class="text-danger fw-bold">{{ formatVND(pointsDiscountAmount) }}</span>
          </label>
        </div>

        <!-- Hiển thị Voucher đã áp dụng -->
        <div
          v-if="appliedVoucher"
          class="d-flex justify-content-between align-items-center px-2 py-1 mt-1 bg-primary bg-opacity-10 border border-primary border-opacity-25 rounded"
        >
          <div class="d-flex align-items-center min-w-0">
            <i class="bi bi-ticket-perforated-fill text-primary me-2"></i>
            <span class="fw-bold text-dark small text-truncate">{{ appliedVoucher.code }}</span>
            <span class="badge bg-primary ms-2 flex-shrink-0">
              {{ appliedVoucher.discountType === 'Percentage'
                ? `-${appliedVoucher.discountValue}%`
                : `-${formatVND(appliedVoucher.discountValue)}` }}
            </span>
          </div>
          <span class="text-danger fw-bold small flex-shrink-0">-{{ formatVND(voucherDiscountAmount) }}</span>
        </div>
      </div>
    </div>

    <div class="flex-grow-1 overflow-auto bg-white custom-scrollbar px-2 py-1">
      <div v-if="!existingOrder && cart.length === 0" class="text-center text-muted py-5 mt-4">
        <i class="bi bi-cart-x display-3 opacity-25"></i>
        <h6 class="mt-2">Giỏ hàng trống</h6>
      </div>

      <div v-else>
        <div v-if="existingItems.length > 0" class="mb-3">
          <h6 class="text-muted fw-bold mb-1 small px-1 bg-light py-1 rounded">
            <i class="bi bi-clock-history"></i> MÓN ĐÃ GỌI ({{ existingItems.length }})
          </h6>
          <div
            v-for="item in existingItems"
            :key="item.id || item.productId"
            class="d-flex justify-content-between align-items-center py-2 border-bottom"
          >
            <div class="text-truncate pe-2">
              <div class="fw-bold text-dark small text-truncate">
                {{ item.productName || item.name || "Món" }}
              </div>
              <div class="text-muted" style="font-size: 0.75rem">
                {{ formatVND(item.unitPrice || item.price) }} x {{ item.quantity }}
              </div>
            </div>
            <div class="fw-bold text-success small text-nowrap">
              {{ formatVND(item.unitPrice * item.quantity) }}
            </div>
          </div>
        </div>

        <div v-if="cart.length > 0">
          <h6 class="text-muted fw-bold mb-1 small px-1 bg-warning bg-opacity-10 py-1 rounded text-warning">
            <i class="bi bi-cart-plus"></i> MÓN MỚI ({{ cart.length }})
          </h6>
          <div
            v-for="item in cart"
            :key="item.productId"
            class="py-2 border-bottom position-relative item-row"
          >
            <div class="d-flex justify-content-between align-items-start mb-1">
              <div class="fw-bold text-dark small text-truncate pe-2 flex-grow-1">{{ item.name }}</div>
              <div class="fw-bold text-danger small text-nowrap">
                {{ formatVND(item.unitPrice * item.quantity) }}
              </div>
            </div>

            <div class="d-flex justify-content-between align-items-center">
              <div class="input-group input-group-sm qty-group" style="width: 85px">
                <button
                  class="btn btn-outline-secondary px-2 py-0"
                  @click="item.quantity > 1 ? item.quantity-- : emit('remove-item', item)"
                >
                  -
                </button>
                <input
                  type="number"
                  class="form-control text-center p-0 fw-bold"
                  v-model="item.quantity"
                  min="1"
                  style="height: 24px"
                />
                <button class="btn btn-outline-secondary px-2 py-0" @click="item.quantity++">+</button>
              </div>

              <div class="d-flex gap-1">
                <input
                  type="text"
                  class="form-control form-control-sm border-0 bg-light px-2 py-0"
                  style="width: 120px; height: 24px; font-size: 0.75rem"
                  placeholder="+ Ghi chú"
                  v-model="item.note"
                />
                <button class="btn btn-sm btn-link text-danger p-0 px-1" @click="emit('remove-item', item)">
                  <i class="bi bi-trash-fill"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="flex-shrink-0 bg-white shadow-lg p-2 z-3 border-top">
      <div
        class="d-flex justify-content-between align-items-center mb-1 px-1"
        v-if="pointsDiscountAmount > 0 || voucherDiscountAmount > 0"
      >
        <span class="text-muted small">Tổng phụ</span>
        <span class="fw-semibold">{{ formatVND(subTotalAmount) }}</span>
      </div>
      <div
        class="d-flex justify-content-between align-items-center mb-1 px-1"
        v-if="pointsDiscountAmount > 0"
      >
        <span class="text-muted small">Trừ điểm</span>
        <span class="fw-semibold text-success">- {{ formatVND(pointsDiscountAmount) }}</span>
      </div>
      <div
        class="d-flex justify-content-between align-items-center mb-1 px-1"
        v-if="voucherDiscountAmount > 0"
      >
        <span class="text-muted small">Voucher <span class="badge bg-primary bg-opacity-75 ms-1">{{ appliedVoucher?.code }}</span></span>
        <span class="fw-semibold text-success">- {{ formatVND(voucherDiscountAmount) }}</span>
      </div>
      <div class="d-flex justify-content-between align-items-center mb-2 px-1 border-top pt-1">
        <span class="fw-bold text-dark small">KHÁCH CẦN TRẢ</span>
        <span class="fs-4 fw-bolder text-danger lh-1">{{ formatVND(finalTotalAmount) }}</span>
      </div>

      <div v-if="selectedTable" class="row g-1">
        <div class="col-12" v-if="!selectedTable.isInUse && selectedTable.tableId !== 'TAKEAWAY'">
          <button class="btn btn-primary w-100 py-2 fw-bold shadow-sm" @click="emit('open-table')">
            <i class="bi bi-unlock-fill me-1"></i> MỞ BÀN
          </button>
        </div>

        <template v-else>
          <div class="col-12 d-flex gap-1" v-if="cart.length > 0 || existingOrder">
            <select
              class="form-select form-select-sm bg-light fw-semibold"
              v-model="selectedPaymentMethod"
              style="width: 35%"
            >
              <option value="Cash">Tiền mặt</option>
              <option value="Banking">Chuyển khoản</option>
              <option value="Card">Thẻ / Ví</option>
            </select>

            <button
              v-if="cart.length > 0"
              class="btn btn-warning btn-sm flex-grow-1 fw-bold text-dark shadow-sm"
              @click="emit('send-to-kitchen', getCheckoutPayload())"
            >
              <i class="bi bi-bell-fill"></i> BÁO BẾP
            </button>

            <template v-if="existingOrder && cart.length === 0">
              <template v-if="existingOrder.paymentMethod === 'Banking'">
                <button
                  class="btn btn-info btn-sm text-white fw-bold shadow-sm px-2 flex-grow-1"
                  @click="emit('print-provisional', getCheckoutPayload())"
                  title="In lại QR"
                >
                  <i class="bi bi-printer-fill"></i> IN LẠI QR
                </button>
                <button
                  class="btn btn-warning btn-sm fw-bold shadow-sm px-2 flex-grow-1 text-dark"
                  @click="emit('show-qr-modal')"
                  title="Đẩy lại ra Màn phụ"
                >
                  <i class="bi bi-display"></i> HIỆN LÊN MÀN HÌNH
                </button>
              </template>
              <template v-else>
                <button
                  class="btn btn-info btn-sm text-white fw-bold shadow-sm px-5"
                  @click="emit('print-provisional', getCheckoutPayload())"
                  title="In Tạm Tính"
                >
                  <i class="bi bi-printer-fill"></i>
                  IN TẠM PHIẾU TÍNH
                </button>
                <button
                  class="btn btn-success btn-sm flex-grow-1 fw-bold shadow-sm"
                  @click="emit('checkout', getCheckoutPayload())"
                >
                  THANH TOÁN
                </button>
              </template>
            </template>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import {ref, computed, watch} from "vue";
import {formatVND} from "@/utils/helpers";
import type {OrderDetailDto} from "./OperationsArea.vue";
import {userService} from "@/services/CustomerService";
import {voucherService} from "@/services/VoucherService";
import type {VoucherDto} from "@/services/VoucherService";
import {toast} from "@/utils/toast";

const props = defineProps<{
  selectedTable: any;
  cart: OrderDetailDto[];
  existingOrder: any;
}>();

const emit = defineEmits([
  "remove-item",
  "send-to-kitchen",
  "checkout",
  "open-table",
  "change-table",
  "print-provisional",
  "add-customer",
  "show-qr-modal"
]);

const existingItems = computed(() => props.existingOrder?.orderDetails || []);

const voucherCode = ref("");
const selectedPaymentMethod = ref("Cash");
const searchQuery = ref("");
const isSearching = ref(false);
const showDropdown = ref(false);
const suggestedCustomers = ref<any[]>([]);
const selectedCustomer = ref<any>(null);
let searchTimeout: any = null;

// 👉 BIẾN ĐIỀU KHIỂN TRỪ ĐIỂM
const useRewardPoints = ref(false);
const DISCOUNT_PER_POINT = 1000; // Cấu hình 1 điểm = 1.000đ (Phải khớp với C#)

// Reset công tắc trừ điểm mỗi khi đổi khách hàng
watch(selectedCustomer, () => {
  useRewardPoints.value = false;
});

// Tính tổng tiền gốc (Chưa trừ điểm)
const subTotalAmount = computed(() => {
  let oldTotal = props.existingOrder?.finalAmount || 0;
  let newTotal = props.cart.reduce((sum, item) => sum + (item.unitPrice || 0) * Number(item.quantity), 0);
  return oldTotal + newTotal;
});

// Thuật toán tính số điểm TỐI ĐA được phép dùng (Không cho trừ âm tiền)
const pointsToUse = computed(() => {
  if (!useRewardPoints.value || !selectedCustomer.value || !selectedCustomer.value.rewardPoints) return 0;

  // Tính xem Bill này quy ra được tối đa bao nhiêu điểm
  const maxPointsByBill = Math.floor(subTotalAmount.value / DISCOUNT_PER_POINT);

  // Trả về con số nhỏ hơn giữa (Điểm khách có) và (Điểm tối đa bill cho phép)
  return Math.min(selectedCustomer.value.rewardPoints, maxPointsByBill);
});

// Tiền được giảm (từ điểm)
const pointsDiscountAmount = computed(() => {
  return pointsToUse.value * DISCOUNT_PER_POINT;
});

// ========== VOUCHER ==========
const appliedVoucher = ref<VoucherDto | null>(null);
const isApplyingVoucher = ref(false);

// Tính tiền giảm từ voucher
const voucherDiscountAmount = computed(() => {
  if (!appliedVoucher.value) return 0;
  const afterPointsDiscount = subTotalAmount.value - pointsDiscountAmount.value;
  if (afterPointsDiscount <= 0) return 0;

  if (appliedVoucher.value.discountType === 'FixedAmount') {
    return Math.min(appliedVoucher.value.discountValue, afterPointsDiscount);
  } else {
    // Percentage
    let discount = afterPointsDiscount * appliedVoucher.value.discountValue / 100;
    if (appliedVoucher.value.maxDiscountAmount && discount > appliedVoucher.value.maxDiscountAmount) {
      discount = appliedVoucher.value.maxDiscountAmount;
    }
    return Math.min(discount, afterPointsDiscount);
  }
});

// Khách cần trả cuối cùng (trừ cả điểm + voucher)
const finalTotalAmount = computed(() => {
  const result = subTotalAmount.value - pointsDiscountAmount.value - voucherDiscountAmount.value;
  return result < 0 ? 0 : result;
});

const applyVoucher = async () => {
  if (!voucherCode.value.trim()) return;
  isApplyingVoucher.value = true;
  try {
    const result = await voucherService.validate(voucherCode.value.trim().toUpperCase(), subTotalAmount.value);
    appliedVoucher.value = result.data;
    toast.success(`Áp dụng mã ${appliedVoucher.value!.code} thành công!`);
  } catch (error: any) {
    const msg = error.response?.data?.message || 'Mã giảm giá không hợp lệ';
    toast.error(msg);
    appliedVoucher.value = null;
  } finally {
    isApplyingVoucher.value = false;
  }
};

const removeVoucher = () => {
  appliedVoucher.value = null;
  voucherCode.value = '';
};

const handleSearch = () => {
  showDropdown.value = true;
  isSearching.value = true;
  clearTimeout(searchTimeout);

  if (!searchQuery.value.trim()) {
    suggestedCustomers.value = [];
    isSearching.value = false;
    return;
  }

  searchTimeout = setTimeout(async () => {
    try {
      const res = await userService.getAll({search: searchQuery.value, pageSize: 15});
      suggestedCustomers.value = (res.data || res).items || [];
    } catch (error) {
      console.error(error);
    } finally {
      isSearching.value = false;
    }
  }, 300);
};

const selectCustomer = (c: any) => {
  selectedCustomer.value = c;
  searchQuery.value = "";
  showDropdown.value = false;
};

const clearCustomer = () => {
  selectedCustomer.value = null;
};

const hideDropdownDelay = () =>
  setTimeout(() => {
    showDropdown.value = false;
  }, 200);

// 👉 GỌI COMPONENT CHA XỬ LÝ VIỆC THÊM KHÁCH
const triggerAddCustomer = () => {
  // Bắn sự kiện ra ngoài kèm theo SĐT/Tên vừa gõ để Component cha mở Modal
  emit("add-customer", searchQuery.value);
  showDropdown.value = false;
};

// Đóng gói Dữ liệu gửi xuống Backend
const getCheckoutPayload = () => ({
  paymentMethod: selectedPaymentMethod.value,
  customerId: selectedCustomer.value?.id || null,
  customerName: selectedCustomer.value?.fullName || searchQuery.value,
  customerPhone: selectedCustomer.value?.phoneNumber || null,
  pointsUsed: pointsToUse.value,
  discountAmount: pointsDiscountAmount.value + voucherDiscountAmount.value,
  finalAmount: finalTotalAmount.value,
  totalAmount: subTotalAmount.value,
  voucherId: appliedVoucher.value?.id || null,
});
</script>

<style scoped>
.cursor-pointer {
  cursor: pointer;
}
.custom-scrollbar::-webkit-scrollbar {
  width: 4px;
}
.custom-scrollbar::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 4px;
}
.min-w-0 {
  min-width: 0;
}
input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
.qty-group .btn {
  border-color: #dee2e6;
  color: #495057;
  background-color: #f8f9fa;
  font-weight: bold;
}
.qty-group input {
  border-color: #dee2e6;
  border-left: 0;
  border-right: 0;
}
</style>
